﻿'Version: 1.0 Created: 15.6.21 Changes: Blank forms inserted, Contacts Class created.
Public Class MainMenu

End Class
