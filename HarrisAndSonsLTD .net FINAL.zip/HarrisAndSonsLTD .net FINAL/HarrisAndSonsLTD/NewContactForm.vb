﻿Imports System
Imports MySql.Data.MySqlClient
    Imports System.Collections.Generic
    Imports System.ComponentModel
    Imports System.Data
    Imports System.Drawing
    Imports System.Drawing.Printing
    Imports System.Linq
    Imports System.Text
    Imports System.Threading.Tasks
    Imports System.Windows.Forms

Namespace HarrisAndSonsLTD
    Partial Public Class NewContactForm
        Inherits Form

        Private mysqlConn As ContactDbConn

        Public Sub New()
            InitializeComponent()
            mysqlConn = New ContactDbConn()
            mysqlConn.connect()
            If mysqlConn.connOpen() = True Then mysqlConn.connClose()
        End Sub

        Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs)
            If tbContactType.Text = "" Then
                MessageBox.Show("Please specify whether the contact is business or personal")
            ElseIf tbFName.Text = "" Then
                MessageBox.Show("Please enter the contact's first name")
            ElseIf tbLName.Text = "" Then
                MessageBox.Show("Please enter the contact's last name")
            ElseIf tbEmail.Text = "" Then
                MessageBox.Show("Please enter the contact's email")
            ElseIf tbAddressLine1.Text = "" Then
                MessageBox.Show("Please enter the first line of the contact's address")
            ElseIf tbAddressLine2.Text = "" Then
                MessageBox.Show("Please enter the second line of the contact's address")
            ElseIf tbCity.Text = "" Then
                MessageBox.Show("Please enter the city of the contact's address")
            ElseIf tbPostcode.Text = "" Then
                MessageBox.Show("Please enter the contact's postcode")
            End If

            If tbFName.Text <> "" And tbLName.Text <> "" And tbHomeTel.Text <> "" And tbEmail.Text <> "" Then

                If mysqlConn.connOpen() = True Then
                    mysqlConn.insertContact(tbContactType.Text, tbFName.Text, tbBusinessTel.Text, tbEmail.Text, tbAddressLine1.Text, tbAddressLine2.Text, tbCity.Text, tbPostcode.Text)
                End If
            End If

            mysqlConn.connClose()
            Close()
            Dim ContactsForm As New ContactsForm
            ContactsForm.Show()
        End Sub
        Private Sub btnMainMenu_Click(sender As Object, e As EventArgs) Handles btnMainMenu.Click
            Dim contactsfrom As New ContactsForm
            contactsfrom.Show()
            Me.Hide()
        End Sub
        Private Sub btnExit_Click(ByVal sender As Object, ByVal e As EventArgs)
            Application.[Exit]()
        End Sub

        Private Sub InitializeComponent()
            Me.title = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.btnMainMenu = New System.Windows.Forms.Button()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.Label3 = New System.Windows.Forms.Label()
            Me.Label4 = New System.Windows.Forms.Label()
            Me.Label5 = New System.Windows.Forms.Label()
            Me.Label6 = New System.Windows.Forms.Label()
            Me.Label7 = New System.Windows.Forms.Label()
            Me.Label8 = New System.Windows.Forms.Label()
            Me.Label9 = New System.Windows.Forms.Label()
            Me.Label10 = New System.Windows.Forms.Label()
            Me.Label11 = New System.Windows.Forms.Label()
            Me.Label12 = New System.Windows.Forms.Label()
            Me.tbContactID = New System.Windows.Forms.TextBox()
            Me.tbContactType = New System.Windows.Forms.TextBox()
            Me.tbFName = New System.Windows.Forms.TextBox()
            Me.tbLName = New System.Windows.Forms.TextBox()
            Me.tbHomeTel = New System.Windows.Forms.TextBox()
            Me.tbBusinessTel = New System.Windows.Forms.TextBox()
            Me.tbEmail = New System.Windows.Forms.TextBox()
            Me.tbAddressLine1 = New System.Windows.Forms.TextBox()
            Me.tbAddressLine2 = New System.Windows.Forms.TextBox()
            Me.tbCity = New System.Windows.Forms.TextBox()
            Me.tbPostcode = New System.Windows.Forms.TextBox()
            Me.btnAdd = New System.Windows.Forms.Button()
            Me.SuspendLayout()
            '
            'title
            '
            Me.title.AutoSize = True
            Me.title.Font = New System.Drawing.Font("Comic Sans MS", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
            Me.title.ForeColor = System.Drawing.Color.Blue
            Me.title.Location = New System.Drawing.Point(53, 9)
            Me.title.Name = "title"
            Me.title.Size = New System.Drawing.Size(327, 29)
            Me.title.TabIndex = 1
            Me.title.Text = "Harris and Sons Consulting LTD."
            '
            'Label1
            '
            Me.Label1.AutoSize = True
            Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
            Me.Label1.ForeColor = System.Drawing.Color.Blue
            Me.Label1.Location = New System.Drawing.Point(121, 50)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(195, 23)
            Me.Label1.TabIndex = 2
            Me.Label1.Text = "Add New Contact Details"
            '
            'btnMainMenu
            '
            Me.btnMainMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.btnMainMenu.Location = New System.Drawing.Point(407, 16)
            Me.btnMainMenu.Name = "btnMainMenu"
            Me.btnMainMenu.Size = New System.Drawing.Size(94, 23)
            Me.btnMainMenu.TabIndex = 3
            Me.btnMainMenu.Text = "Back"
            Me.btnMainMenu.UseVisualStyleBackColor = False
            '
            'Label2
            '
            Me.Label2.AutoSize = True
            Me.Label2.Location = New System.Drawing.Point(125, 96)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(66, 15)
            Me.Label2.TabIndex = 4
            Me.Label2.Text = "Contact ID:"
            '
            'Label3
            '
            Me.Label3.AutoSize = True
            Me.Label3.Location = New System.Drawing.Point(12, 125)
            Me.Label3.Name = "Label3"
            Me.Label3.Size = New System.Drawing.Size(180, 15)
            Me.Label3.TabIndex = 5
            Me.Label3.Text = "Contact Type: Personal/Business:"
            '
            'Label4
            '
            Me.Label4.AutoSize = True
            Me.Label4.Location = New System.Drawing.Point(80, 154)
            Me.Label4.Name = "Label4"
            Me.Label4.Size = New System.Drawing.Size(112, 15)
            Me.Label4.TabIndex = 6
            Me.Label4.Text = "Contact First Name:"
            '
            'Label5
            '
            Me.Label5.AutoSize = True
            Me.Label5.Location = New System.Drawing.Point(81, 183)
            Me.Label5.Name = "Label5"
            Me.Label5.Size = New System.Drawing.Size(111, 15)
            Me.Label5.TabIndex = 7
            Me.Label5.Text = "Contact Last Name:"
            '
            'Label6
            '
            Me.Label6.AutoSize = True
            Me.Label6.Location = New System.Drawing.Point(47, 212)
            Me.Label6.Name = "Label6"
            Me.Label6.Size = New System.Drawing.Size(145, 15)
            Me.Label6.TabIndex = 8
            Me.Label6.Text = "Contact Home Telephone:"
            '
            'Label7
            '
            Me.Label7.AutoSize = True
            Me.Label7.Location = New System.Drawing.Point(35, 241)
            Me.Label7.Name = "Label7"
            Me.Label7.Size = New System.Drawing.Size(157, 15)
            Me.Label7.TabIndex = 9
            Me.Label7.Text = "Contact Business Telephone:"
            '
            'Label8
            '
            Me.Label8.AutoSize = True
            Me.Label8.Location = New System.Drawing.Point(108, 270)
            Me.Label8.Name = "Label8"
            Me.Label8.Size = New System.Drawing.Size(84, 15)
            Me.Label8.TabIndex = 10
            Me.Label8.Text = "Contact Email:"
            '
            'Label9
            '
            Me.Label9.AutoSize = True
            Me.Label9.Location = New System.Drawing.Point(61, 320)
            Me.Label9.Name = "Label9"
            Me.Label9.Size = New System.Drawing.Size(131, 15)
            Me.Label9.TabIndex = 11
            Me.Label9.Text = "Contact Address Line 1:"
            '
            'Label10
            '
            Me.Label10.AutoSize = True
            Me.Label10.Location = New System.Drawing.Point(61, 349)
            Me.Label10.Name = "Label10"
            Me.Label10.Size = New System.Drawing.Size(131, 15)
            Me.Label10.TabIndex = 12
            Me.Label10.Text = "Contact Address Line 2:"
            '
            'Label11
            '
            Me.Label11.AutoSize = True
            Me.Label11.Location = New System.Drawing.Point(116, 378)
            Me.Label11.Name = "Label11"
            Me.Label11.Size = New System.Drawing.Size(76, 15)
            Me.Label11.TabIndex = 13
            Me.Label11.Text = "Contact City:"
            '
            'Label12
            '
            Me.Label12.AutoSize = True
            Me.Label12.Location = New System.Drawing.Point(88, 407)
            Me.Label12.Name = "Label12"
            Me.Label12.Size = New System.Drawing.Size(104, 15)
            Me.Label12.TabIndex = 14
            Me.Label12.Text = "Contact Postcode:"
            '
            'tbContactID
            '
            Me.tbContactID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
            Me.tbContactID.Location = New System.Drawing.Point(198, 93)
            Me.tbContactID.Name = "tbContactID"
            Me.tbContactID.Size = New System.Drawing.Size(181, 23)
            Me.tbContactID.TabIndex = 15
            '
            'tbContactType
            '
            Me.tbContactType.BackColor = System.Drawing.Color.White
            Me.tbContactType.Location = New System.Drawing.Point(198, 122)
            Me.tbContactType.Name = "tbContactType"
            Me.tbContactType.Size = New System.Drawing.Size(182, 23)
            Me.tbContactType.TabIndex = 16
            '
            'tbFName
            '
            Me.tbFName.BackColor = System.Drawing.Color.White
            Me.tbFName.Location = New System.Drawing.Point(198, 151)
            Me.tbFName.Name = "tbFName"
            Me.tbFName.Size = New System.Drawing.Size(182, 23)
            Me.tbFName.TabIndex = 17
            '
            'tbLName
            '
            Me.tbLName.BackColor = System.Drawing.Color.White
            Me.tbLName.Location = New System.Drawing.Point(198, 180)
            Me.tbLName.Name = "tbLName"
            Me.tbLName.Size = New System.Drawing.Size(182, 23)
            Me.tbLName.TabIndex = 18
            '
            'tbHomeTel
            '
            Me.tbHomeTel.BackColor = System.Drawing.Color.White
            Me.tbHomeTel.Location = New System.Drawing.Point(198, 209)
            Me.tbHomeTel.Name = "tbHomeTel"
            Me.tbHomeTel.Size = New System.Drawing.Size(182, 23)
            Me.tbHomeTel.TabIndex = 19
            '
            'tbBusinessTel
            '
            Me.tbBusinessTel.BackColor = System.Drawing.Color.White
            Me.tbBusinessTel.Location = New System.Drawing.Point(198, 238)
            Me.tbBusinessTel.Name = "tbBusinessTel"
            Me.tbBusinessTel.Size = New System.Drawing.Size(182, 23)
            Me.tbBusinessTel.TabIndex = 20
            '
            'tbEmail
            '
            Me.tbEmail.BackColor = System.Drawing.Color.White
            Me.tbEmail.Location = New System.Drawing.Point(198, 267)
            Me.tbEmail.Name = "tbEmail"
            Me.tbEmail.Size = New System.Drawing.Size(182, 23)
            Me.tbEmail.TabIndex = 21
            '
            'tbAddressLine1
            '
            Me.tbAddressLine1.BackColor = System.Drawing.Color.White
            Me.tbAddressLine1.Location = New System.Drawing.Point(198, 317)
            Me.tbAddressLine1.Name = "tbAddressLine1"
            Me.tbAddressLine1.Size = New System.Drawing.Size(182, 23)
            Me.tbAddressLine1.TabIndex = 22
            '
            'tbAddressLine2
            '
            Me.tbAddressLine2.BackColor = System.Drawing.Color.White
            Me.tbAddressLine2.Location = New System.Drawing.Point(198, 346)
            Me.tbAddressLine2.Name = "tbAddressLine2"
            Me.tbAddressLine2.Size = New System.Drawing.Size(182, 23)
            Me.tbAddressLine2.TabIndex = 23
            '
            'tbCity
            '
            Me.tbCity.BackColor = System.Drawing.Color.White
            Me.tbCity.Location = New System.Drawing.Point(198, 375)
            Me.tbCity.Name = "tbCity"
            Me.tbCity.Size = New System.Drawing.Size(182, 23)
            Me.tbCity.TabIndex = 24
            '
            'tbPostcode
            '
            Me.tbPostcode.BackColor = System.Drawing.Color.White
            Me.tbPostcode.Location = New System.Drawing.Point(198, 404)
            Me.tbPostcode.Name = "tbPostcode"
            Me.tbPostcode.Size = New System.Drawing.Size(182, 23)
            Me.tbPostcode.TabIndex = 25
            '
            'btnAdd
            '
            Me.btnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.btnAdd.Location = New System.Drawing.Point(241, 433)
            Me.btnAdd.Name = "btnAdd"
            Me.btnAdd.Size = New System.Drawing.Size(75, 23)
            Me.btnAdd.TabIndex = 26
            Me.btnAdd.Text = "Add"
            Me.btnAdd.UseVisualStyleBackColor = False
            '
            'NewContactForm
            '
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(513, 480)
            Me.Controls.Add(Me.btnAdd)
            Me.Controls.Add(Me.tbPostcode)
            Me.Controls.Add(Me.tbCity)
            Me.Controls.Add(Me.tbAddressLine2)
            Me.Controls.Add(Me.tbAddressLine1)
            Me.Controls.Add(Me.tbEmail)
            Me.Controls.Add(Me.tbBusinessTel)
            Me.Controls.Add(Me.tbHomeTel)
            Me.Controls.Add(Me.tbLName)
            Me.Controls.Add(Me.tbFName)
            Me.Controls.Add(Me.tbContactType)
            Me.Controls.Add(Me.tbContactID)
            Me.Controls.Add(Me.Label12)
            Me.Controls.Add(Me.Label11)
            Me.Controls.Add(Me.Label10)
            Me.Controls.Add(Me.Label9)
            Me.Controls.Add(Me.Label8)
            Me.Controls.Add(Me.Label7)
            Me.Controls.Add(Me.Label6)
            Me.Controls.Add(Me.Label5)
            Me.Controls.Add(Me.Label4)
            Me.Controls.Add(Me.Label3)
            Me.Controls.Add(Me.Label2)
            Me.Controls.Add(Me.btnMainMenu)
            Me.Controls.Add(Me.Label1)
            Me.Controls.Add(Me.title)
            Me.Name = "NewContactForm"
            Me.Text = "NewContact"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

        Friend WithEvents title As Label
        Friend WithEvents Label1 As Label
        Friend WithEvents btnMainMenu As Button
        Friend WithEvents Label2 As Label
        Friend WithEvents Label3 As Label
        Friend WithEvents Label4 As Label
        Friend WithEvents Label5 As Label
        Friend WithEvents Label6 As Label
        Friend WithEvents Label7 As Label
        Friend WithEvents Label8 As Label
        Friend WithEvents Label9 As Label
        Friend WithEvents Label10 As Label
        Friend WithEvents Label11 As Label
        Friend WithEvents Label12 As Label
        Friend WithEvents tbContactID As TextBox
        Friend WithEvents tbContactType As TextBox
        Friend WithEvents tbFName As TextBox
        Friend WithEvents tbLName As TextBox
        Friend WithEvents tbHomeTel As TextBox
        Friend WithEvents tbBusinessTel As TextBox
        Friend WithEvents tbEmail As TextBox
        Friend WithEvents tbAddressLine1 As TextBox
        Friend WithEvents tbAddressLine2 As TextBox
        Friend WithEvents tbCity As TextBox
        Friend WithEvents tbPostcode As TextBox
        Friend WithEvents btnAdd As Button
    End Class
End Namespace