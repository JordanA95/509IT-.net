﻿Imports System
Imports MySql.Data.MySqlClient
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Drawing.Printing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Namespace AzmanSys
    Partial Public Class ContactsForm
        Inherits Form

        Private mysqlConn As ContactDbConn

        Public Sub New()
            InitializeComponent()
            mysqlConn = New ContactDbConn()
            mysqlConn.connect()

            If mysqlConn.connOpen() = True Then
                dataGridViewContacts.DataSource = mysqlConn.qry("SELECT * FROM `Contacts`").Tables(0)
            End If

            mysqlConn.connClose()
        End Sub

        Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
            Dim newcontactform As New newcontactForm
            newcontactform.Show()
            Me.Hide()
        End Sub
        Private Sub btnDelete_Click(ByVal sender As Object, ByVal e As EventArgs)
            If DialogResult.Yes = MessageBox.Show("Are you sure you want to delete this record ?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) Then

                If mysqlConn.connOpen() = True Then
                    dataGridViewContacts.DataSource = mysqlConn.qry("SELECT * FROM `Contacts`").Tables(0)
                End If

                mysqlConn.connClose()
            End If
        End Sub
        Private Sub dataGridView1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs)
        End Sub

        Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
            Dim loginform As New loginForm
            loginform.Show()
            Me.Hide()
        End Sub

        Private Sub Refreshbtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            dataGridViewContacts.DataSource = mysqlConn.qry("SELECT * FROM `Contacts`").Tables(0)
        End Sub

        Friend WithEvents logintitle As Label
        Friend WithEvents Label1 As Label
        Friend WithEvents btnAdd As Button
        Friend WithEvents btnUpdate As Button
        Friend WithEvents btnDelete As Button
        Friend WithEvents btnLogOut As Button

        Private Sub InitializeComponent()
            Me.logintitle = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.btnAdd = New System.Windows.Forms.Button()
            Me.btnUpdate = New System.Windows.Forms.Button()
            Me.btnDelete = New System.Windows.Forms.Button()
            Me.btnLogOut = New System.Windows.Forms.Button()
            Me.Refreshbtn = New System.Windows.Forms.Button()
            Me.dataGridViewContacts = New System.Windows.Forms.DataGridView()
            CType(Me.dataGridViewContacts, System.ComponentModel.ISupportInitialize).BeginInit()
            Me.SuspendLayout()
            '
            'logintitle
            '
            Me.logintitle.AutoSize = True
            Me.logintitle.Font = New System.Drawing.Font("Comic Sans MS", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
            Me.logintitle.ForeColor = System.Drawing.Color.Blue
            Me.logintitle.Location = New System.Drawing.Point(234, 12)
            Me.logintitle.Name = "logintitle"
            Me.logintitle.Size = New System.Drawing.Size(327, 29)
            Me.logintitle.TabIndex = 0
            Me.logintitle.Text = "Harris and Sons Consulting LTD."
            '
            'Label1
            '
            Me.Label1.AutoSize = True
            Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
            Me.Label1.ForeColor = System.Drawing.Color.Blue
            Me.Label1.Location = New System.Drawing.Point(333, 57)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(112, 23)
            Me.Label1.TabIndex = 1
            Me.Label1.Text = "View Contacts"
            '
            'btnAdd
            '
            Me.btnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.btnAdd.Location = New System.Drawing.Point(12, 99)
            Me.btnAdd.Name = "btnAdd"
            Me.btnAdd.Size = New System.Drawing.Size(124, 25)
            Me.btnAdd.TabIndex = 2
            Me.btnAdd.Text = "Add New Contact"
            Me.btnAdd.UseVisualStyleBackColor = False
            '
            'btnUpdate
            '
            Me.btnUpdate.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.btnUpdate.Location = New System.Drawing.Point(12, 130)
            Me.btnUpdate.Name = "btnUpdate"
            Me.btnUpdate.Size = New System.Drawing.Size(124, 25)
            Me.btnUpdate.TabIndex = 3
            Me.btnUpdate.Text = "Update Contact"
            Me.btnUpdate.UseVisualStyleBackColor = False
            '
            'btnDelete
            '
            Me.btnDelete.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.btnDelete.Location = New System.Drawing.Point(12, 161)
            Me.btnDelete.Name = "btnDelete"
            Me.btnDelete.Size = New System.Drawing.Size(124, 25)
            Me.btnDelete.TabIndex = 4
            Me.btnDelete.Text = "Delete Contact"
            Me.btnDelete.UseVisualStyleBackColor = False
            '
            'btnLogOut
            '
            Me.btnLogOut.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.btnLogOut.Location = New System.Drawing.Point(667, 12)
            Me.btnLogOut.Name = "btnLogOut"
            Me.btnLogOut.Size = New System.Drawing.Size(137, 25)
            Me.btnLogOut.TabIndex = 5
            Me.btnLogOut.Text = "Log Out"
            Me.btnLogOut.UseVisualStyleBackColor = False
            '
            'Refreshbtn
            '
            Me.Refreshbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.Refreshbtn.Location = New System.Drawing.Point(723, 434)
            Me.Refreshbtn.Name = "Refreshbtn"
            Me.Refreshbtn.Size = New System.Drawing.Size(81, 25)
            Me.Refreshbtn.TabIndex = 6
            Me.Refreshbtn.Text = "Refresh"
            Me.Refreshbtn.UseVisualStyleBackColor = False
            '
            'dataGridViewContacts
            '
            Me.dataGridViewContacts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
            Me.dataGridViewContacts.Location = New System.Drawing.Point(12, 192)
            Me.dataGridViewContacts.Name = "dataGridViewContacts"
            Me.dataGridViewContacts.RowTemplate.Height = 25
            Me.dataGridViewContacts.Size = New System.Drawing.Size(705, 267)
            Me.dataGridViewContacts.TabIndex = 7
            '
            'ContactsForm
            '
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(816, 471)
            Me.Controls.Add(Me.dataGridViewContacts)
            Me.Controls.Add(Me.Refreshbtn)
            Me.Controls.Add(Me.btnLogOut)
            Me.Controls.Add(Me.btnDelete)
            Me.Controls.Add(Me.btnUpdate)
            Me.Controls.Add(Me.btnAdd)
            Me.Controls.Add(Me.Label1)
            Me.Controls.Add(Me.logintitle)
            Me.Name = "ContactsForm"
            Me.Text = "Contacts"
            CType(Me.dataGridViewContacts, System.ComponentModel.ISupportInitialize).EndInit()
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

        Friend WithEvents Refreshbtn As Button
        Friend WithEvents dataGridViewContacts As DataGridView
    End Class
End Namespace