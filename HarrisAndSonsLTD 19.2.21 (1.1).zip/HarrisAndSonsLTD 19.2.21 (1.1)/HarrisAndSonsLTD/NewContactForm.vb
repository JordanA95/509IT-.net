﻿Public Class newcontactForm
    Imports System
    Imports MySql.Data.MySqlClient
    Imports System.Collections.Generic
    Imports System.ComponentModel
    Imports System.Data
    Imports System.Drawing
    Imports System.Drawing.Printing
    Imports System.Linq
    Imports System.Text
    Imports System.Threading.Tasks
    Imports System.Windows.Forms

Namespace AzmanSys
    Partial Public Class NewContactForm
        Inherits Form

        Private mysqlConn As ContactDbConn

        Public Sub New()
            InitializeComponent()
            mysqlConn = New ContactDbConn()
            mysqlConn.connect()
            If mysqlConn.connOpen() = True Then mysqlConn.connClose()
        End Sub

        Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As EventArgs)
            If tbContactType.Text = "" Then
                MessageBox.Show("Please specify whether the contact is business or personal")
            ElseIf tbFName.Text = "" Then
                MessageBox.Show("Please enter the contact's first name")
            ElseIf tbLName.Text = "" Then
                MessageBox.Show("Please enter the contact's last name")
            ElseIf tbEmail.Text = "" Then
                MessageBox.Show("Please enter the contact's email")
            ElseIf tbAddressLine1.Text = "" Then
                MessageBox.Show("Please enter the first line of the contact's address")
            ElseIf tbAddressLine2.Text = "" Then
                MessageBox.Show("Please enter the second line of the contact's address")
            ElseIf tbCity.Text = "" Then
                MessageBox.Show("Please enter the city of the contact's address")
            ElseIf tbPostcode.Text = "" Then
                MessageBox.Show("Please enter the contact's postcode")
            End If

            If tbFName.Text <> "" And tbLName.Text <> "" And tbHomeTel.Text <> "" And tbEmail.Text <> "" Then

                If mysqlConn.connOpen() = True Then
                    mysqlConn.insertContact(tbContactType.Text, tbFName.Text, tbBusinessTel.Text, tbEmail.Text, tbAddressLine1.Text, tbAddressLine2.Text, tbCity.Text, tbPostcode.Text)
                End If
            End If

            mysqlConn.connClose()
            Close()
            (New ContactsForm()).Show()
        End Sub
        Private Sub btnMainMenu_Click(sender As Object, e As EventArgs) Handles btnMainMenu.Click
            Dim contactsfrom As New contactsForm
            contactsfrom.Show()
            Me.Hide()
        End Sub
        Private Sub btnExit_Click(ByVal sender As Object, ByVal e As EventArgs)
            Application.[Exit]()
        End Sub

    End Class
End Namespace