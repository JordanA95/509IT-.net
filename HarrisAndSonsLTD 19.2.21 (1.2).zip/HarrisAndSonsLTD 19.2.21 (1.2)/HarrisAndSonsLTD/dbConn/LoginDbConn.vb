﻿Imports MySql.Data.MySqlClient
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Namespace HarrisAndSonsLTD
    Public Class LoginDbConn
        Inherits dbConn

        Public Sub ValidateLogin(ByVal Username As String, ByVal Password As String)
            Dim comm As MySqlCommand = conn.CreateCommand()
            comm.CommandText = "SELECT*FROM Login where Username=@Username AND Password=@Password"
            comm.Parameters.AddWithValue("@Username", Username)
            comm.Parameters.AddWithValue("@Password", Password)
            MessageBox.Show("Login sucessful")
            comm.ExecuteNonQuery()
            connClose()
        End Sub
    End Class
End Namespace

