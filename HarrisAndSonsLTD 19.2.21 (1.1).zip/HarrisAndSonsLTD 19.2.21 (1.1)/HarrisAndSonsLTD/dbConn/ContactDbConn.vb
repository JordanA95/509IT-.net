﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports MySql.Data
Imports MySql.Data.MySqlClient

Namespace AzmanSys
    Public Class ContactDbConn
        Inherits dbConn

        Public Sub insertContact(ByVal ContactType As String, ByVal ContactFName As String, ByVal ContactLName As String, ByVal ContactHomeTel As Integer, ByVal ContactBusinessTel As Integer, ByVal ContactEmail As String, ByVal ContactAddr1 As String, ByVal ContactAddr2 As String, ByVal ContactCity As String, ByVal ContactPostcode As String)
            Dim comm As MySqlCommand = conn.CreateCommand()
            comm.CommandText = "UPDATE `Contacts` SET 'ContactType'=@ContactType, 'ContactFName'=@ContactFName, 'ContactLName'=@ContactLName, 'ContactHomeTel'=@ContactHomeTel, 'ContactBusinessTel'=@ContactBusinessTel, 'ContactEmail'=@ContactEmail, 'ContactAddr1'=@ContactAddr1, 'ContactAddr2'=@ContactAddr2, 'ContactCity'=@ContactCity, 'ContactPostcode'=@ContactPostcode WHERE ContactID=@ContactID"
            comm.Parameters.AddWithValue("@ContactType", ContactType)
            comm.Parameters.AddWithValue("@ContactFName", ContactFName)
            comm.Parameters.AddWithValue("@ContactLName", ContactLName)
            comm.Parameters.AddWithValue("@ContactHomeTel", ContactHomeTel)
            comm.Parameters.AddWithValue("@ContactBusinessTel", ContactBusinessTel)
            comm.Parameters.AddWithValue("@ContactEmail", ContactEmail)
            comm.Parameters.AddWithValue("@ContactAddr1", ContactAddr1)
            comm.Parameters.AddWithValue("@ContactAddr2", ContactAddr2)
            comm.Parameters.AddWithValue("@ContactCity", ContactCity)
            comm.Parameters.AddWithValue("@ContactPostcode", ContactPostcode)
            comm.ExecuteNonQuery()
            connClose()
        End Sub

        Friend Sub deleteContact(ByVal text As String)
            Throw New NotImplementedException()
        End Sub

        Public Sub updateContact(ByVal ContactID As Integer, ByVal ContactType As String, ByVal ContactFName As String, ByVal ContactLName As String, ByVal ContactHomeTel As Integer, ByVal ContactBusinessTel As Integer, ByVal ContactEmail As String, ByVal ContactAddr1 As String, ByVal ContactAddr2 As String, ByVal ContactCity As String, ByVal ContactPostcode As String)
            Dim comm As MySqlCommand = conn.CreateCommand()
            comm.CommandText = "UPDATE `Contacts` SET 'ContactType'=@ContactType, 'ContactFName'=@ContactFName, 'ContactLName'=@ContactLName, 'ContactHomeTel'=@ContactHomeTel, 'ContactBusinessTel'=@ContactBusinessTel, 'ContactEmail'=@ContactEmail, 'ContactAddr1'=@ContactAddr1, 'ContactAddr2'=@ContactAddr2, 'ContactCity'=@ContactCity, 'ContactPostcode'=@ContactPostcode WHERE ContactID=@ContactID"
            comm.Parameters.AddWithValue("@ContactID", ContactID)
            comm.Parameters.AddWithValue("@ContactType", ContactType)
            comm.Parameters.AddWithValue("@ContactFName", ContactFName)
            comm.Parameters.AddWithValue("@ContactLName", ContactLName)
            comm.Parameters.AddWithValue("@ContactHomeTel", ContactHomeTel)
            comm.Parameters.AddWithValue("@ContactBusinessTel", ContactBusinessTel)
            comm.Parameters.AddWithValue("@ContactEmail", ContactEmail)
            comm.Parameters.AddWithValue("@ContactAddr1", ContactAddr1)
            comm.Parameters.AddWithValue("@ContactAddr2", ContactAddr2)
            comm.Parameters.AddWithValue("@ContactCity", ContactCity)
            comm.Parameters.AddWithValue("@ContactPostcode", ContactPostcode)
            comm.ExecuteNonQuery()
            connClose()
        End Sub

        Friend Sub insertContact(ByVal text1 As String, ByVal text2 As String, ByVal text3 As String, ByVal text4 As String, ByVal text5 As String, ByVal text6 As String, ByVal text7 As String, ByVal text8 As String)
            Throw New NotImplementedException()
        End Sub

        Public Sub deleteContact(ByVal ContactID As Integer)
            Dim comm As MySqlCommand = conn.CreateCommand()
            comm.CommandText = "DELETE FROM `Contacts` WHERE 'ContactID' = @ContactID"
            comm.Parameters.AddWithValue("@ContactID", ContactID)
            comm.ExecuteNonQuery()
            connClose()
        End Sub
    End Class
End Namespace

