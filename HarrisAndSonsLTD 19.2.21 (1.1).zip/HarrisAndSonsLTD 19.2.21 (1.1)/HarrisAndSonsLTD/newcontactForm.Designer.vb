﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class newcontactForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.logintitle = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnMainMenu = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbContactID = New System.Windows.Forms.TextBox()
        Me.tbContactType = New System.Windows.Forms.TextBox()
        Me.tbFName = New System.Windows.Forms.TextBox()
        Me.tbLName = New System.Windows.Forms.TextBox()
        Me.tbHomeTel = New System.Windows.Forms.TextBox()
        Me.tbBusinessTel = New System.Windows.Forms.TextBox()
        Me.tbEmail = New System.Windows.Forms.TextBox()
        Me.tbAddressLine1 = New System.Windows.Forms.TextBox()
        Me.tbAddressLine2 = New System.Windows.Forms.TextBox()
        Me.tbCity = New System.Windows.Forms.TextBox()
        Me.tbPostcode = New System.Windows.Forms.TextBox()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'logintitle
        '
        Me.logintitle.AutoSize = True
        Me.logintitle.Font = New System.Drawing.Font("Comic Sans MS", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.logintitle.ForeColor = System.Drawing.Color.Blue
        Me.logintitle.Location = New System.Drawing.Point(121, 9)
        Me.logintitle.Name = "logintitle"
        Me.logintitle.Size = New System.Drawing.Size(327, 29)
        Me.logintitle.TabIndex = 2
        Me.logintitle.Text = "Harris and Sons Consulting LTD."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(207, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Add New Contact"
        '
        'btnMainMenu
        '
        Me.btnMainMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnMainMenu.Location = New System.Drawing.Point(494, 12)
        Me.btnMainMenu.Name = "btnMainMenu"
        Me.btnMainMenu.Size = New System.Drawing.Size(75, 23)
        Me.btnMainMenu.TabIndex = 4
        Me.btnMainMenu.Text = "Back"
        Me.btnMainMenu.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(203, 135)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 15)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Contact ID:"
        '
        'tbContactID
        '
        Me.tbContactID.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tbContactID.Location = New System.Drawing.Point(275, 132)
        Me.tbContactID.Name = "tbContactID"
        Me.tbContactID.Size = New System.Drawing.Size(234, 23)
        Me.tbContactID.TabIndex = 6
        '
        'tbContactType
        '
        Me.tbContactType.Location = New System.Drawing.Point(275, 161)
        Me.tbContactType.Name = "tbContactType"
        Me.tbContactType.Size = New System.Drawing.Size(234, 23)
        Me.tbContactType.TabIndex = 7
        '
        'tbFName
        '
        Me.tbFName.Location = New System.Drawing.Point(275, 190)
        Me.tbFName.Name = "tbFName"
        Me.tbFName.Size = New System.Drawing.Size(234, 23)
        Me.tbFName.TabIndex = 8
        '
        'tbLName
        '
        Me.tbLName.Location = New System.Drawing.Point(275, 219)
        Me.tbLName.Name = "tbLName"
        Me.tbLName.Size = New System.Drawing.Size(234, 23)
        Me.tbLName.TabIndex = 9
        '
        'tbHomeTel
        '
        Me.tbHomeTel.Location = New System.Drawing.Point(275, 248)
        Me.tbHomeTel.Name = "tbHomeTel"
        Me.tbHomeTel.Size = New System.Drawing.Size(234, 23)
        Me.tbHomeTel.TabIndex = 10
        '
        'tbBusinessTel
        '
        Me.tbBusinessTel.Location = New System.Drawing.Point(275, 277)
        Me.tbBusinessTel.Name = "tbBusinessTel"
        Me.tbBusinessTel.Size = New System.Drawing.Size(234, 23)
        Me.tbBusinessTel.TabIndex = 11
        '
        'tbEmail
        '
        Me.tbEmail.Location = New System.Drawing.Point(275, 306)
        Me.tbEmail.Name = "tbEmail"
        Me.tbEmail.Size = New System.Drawing.Size(234, 23)
        Me.tbEmail.TabIndex = 12
        '
        'tbAddressLine1
        '
        Me.tbAddressLine1.Location = New System.Drawing.Point(275, 358)
        Me.tbAddressLine1.Name = "tbAddressLine1"
        Me.tbAddressLine1.Size = New System.Drawing.Size(234, 23)
        Me.tbAddressLine1.TabIndex = 13
        '
        'tbAddressLine2
        '
        Me.tbAddressLine2.Location = New System.Drawing.Point(275, 387)
        Me.tbAddressLine2.Name = "tbAddressLine2"
        Me.tbAddressLine2.Size = New System.Drawing.Size(234, 23)
        Me.tbAddressLine2.TabIndex = 14
        '
        'tbCity
        '
        Me.tbCity.Location = New System.Drawing.Point(275, 416)
        Me.tbCity.Name = "tbCity"
        Me.tbCity.Size = New System.Drawing.Size(234, 23)
        Me.tbCity.TabIndex = 15
        '
        'tbPostcode
        '
        Me.tbPostcode.Location = New System.Drawing.Point(275, 445)
        Me.tbPostcode.Name = "tbPostcode"
        Me.tbPostcode.Size = New System.Drawing.Size(234, 23)
        Me.tbPostcode.TabIndex = 16
        '
        'btnAdd
        '
        Me.btnAdd.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.btnAdd.Location = New System.Drawing.Point(265, 495)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 23)
        Me.btnAdd.TabIndex = 17
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(89, 164)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(180, 15)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Contact Type: Personal/Business:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(157, 193)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 15)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Contact First Name:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(158, 222)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(111, 15)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Contact Last Name:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(124, 251)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(145, 15)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = "Contact Home Telephone:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(112, 280)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(157, 15)
        Me.Label7.TabIndex = 22
        Me.Label7.Text = "Contact Business Telephone:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(185, 309)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 15)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Contact Email:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(138, 361)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(131, 15)
        Me.Label9.TabIndex = 24
        Me.Label9.Text = "Contact Address Line 1:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(138, 390)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(131, 15)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "Contact Address Line 2:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(193, 419)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 15)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Contact City:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(165, 448)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(104, 15)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "Contact Postcode:"
        '
        'newcontactForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(581, 530)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.tbPostcode)
        Me.Controls.Add(Me.tbCity)
        Me.Controls.Add(Me.tbAddressLine2)
        Me.Controls.Add(Me.tbAddressLine1)
        Me.Controls.Add(Me.tbEmail)
        Me.Controls.Add(Me.tbBusinessTel)
        Me.Controls.Add(Me.tbHomeTel)
        Me.Controls.Add(Me.tbLName)
        Me.Controls.Add(Me.tbFName)
        Me.Controls.Add(Me.tbContactType)
        Me.Controls.Add(Me.tbContactID)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnMainMenu)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.logintitle)
        Me.Name = "newcontactForm"
        Me.Text = "NewContact"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents logintitle As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnMainMenu As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents tbContactID As TextBox
    Friend WithEvents tbContactType As TextBox
    Friend WithEvents tbFName As TextBox
    Friend WithEvents tbLName As TextBox
    Friend WithEvents tbHomeTel As TextBox
    Friend WithEvents tbBusinessTel As TextBox
    Friend WithEvents tbEmail As TextBox
    Friend WithEvents tbAddressLine1 As TextBox
    Friend WithEvents tbAddressLine2 As TextBox
    Friend WithEvents tbCity As TextBox
    Friend WithEvents tbPostcode As TextBox
    Friend WithEvents btnAdd As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
End Class
