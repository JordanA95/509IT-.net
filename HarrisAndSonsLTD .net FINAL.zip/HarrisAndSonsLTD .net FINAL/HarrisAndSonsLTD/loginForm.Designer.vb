﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class LoginForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.logintitle = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Usernametxb = New System.Windows.Forms.TextBox()
        Me.Passwordtxb = New System.Windows.Forms.TextBox()
        Me.Signinbtn = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'logintitle
        '
        Me.logintitle.AutoSize = True
        Me.logintitle.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.logintitle.ForeColor = System.Drawing.Color.Blue
        Me.logintitle.Location = New System.Drawing.Point(44, 9)
        Me.logintitle.Name = "logintitle"
        Me.logintitle.Size = New System.Drawing.Size(247, 23)
        Me.logintitle.TabIndex = 0
        Me.logintitle.Text = "Harris and Sons Consulting LTD."
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(44, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Username:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(44, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Password:"
        '
        'Usernametxb
        '
        Me.Usernametxb.Location = New System.Drawing.Point(113, 69)
        Me.Usernametxb.Name = "Usernametxb"
        Me.Usernametxb.Size = New System.Drawing.Size(178, 23)
        Me.Usernametxb.TabIndex = 3
        Me.Usernametxb.Text = """Testuser"""
        '
        'Passwordtxb
        '
        Me.Passwordtxb.Location = New System.Drawing.Point(110, 116)
        Me.Passwordtxb.Name = "Passwordtxb"
        Me.Passwordtxb.Size = New System.Drawing.Size(181, 23)
        Me.Passwordtxb.TabIndex = 4
        Me.Passwordtxb.Text = "password"
        '
        'Signinbtn
        '
        Me.Signinbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Signinbtn.Location = New System.Drawing.Point(110, 162)
        Me.Signinbtn.Name = "Signinbtn"
        Me.Signinbtn.Size = New System.Drawing.Size(112, 54)
        Me.Signinbtn.TabIndex = 5
        Me.Signinbtn.Text = "Log In"
        Me.Signinbtn.UseVisualStyleBackColor = False
        '
        'login
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(333, 290)
        Me.Controls.Add(Me.Signinbtn)
        Me.Controls.Add(Me.Passwordtxb)
        Me.Controls.Add(Me.Usernametxb)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.logintitle)
        Me.Name = "login"
        Me.Text = "login"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents logintitle As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Usernametxb As TextBox
    Friend WithEvents Passwordtxb As TextBox
    Friend WithEvents Signinbtn As Button
End Class
