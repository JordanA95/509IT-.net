﻿Public Class newcontact
    Private Sub btnMainMenu_Click(sender As Object, e As EventArgs) Handles btnMainMenu.Click
        Dim contactsfrom As New contacts
        contactsfrom.Show()
        Me.Hide()
    End Sub
End Class