﻿Public Class contacts
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim newcontactform As New newcontact
        newcontactform.Show()
        Me.Hide()
    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click
        Dim loginform As New login
        loginform.Show()
        Me.Hide()
    End Sub
End Class