﻿Public Class login
    Private Sub Signinbtn_Click(sender As Object, e As EventArgs) Handles Signinbtn.Click
        Dim contactsform As New contacts
        contactsform.Show()
        Me.Hide()
    End Sub
End Class
