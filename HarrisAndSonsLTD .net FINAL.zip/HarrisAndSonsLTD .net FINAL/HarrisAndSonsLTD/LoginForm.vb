﻿Imports System
Imports MySql.Data.MySqlClient
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Linq
Imports System.Text
Imports System.Threading.Tasks
Imports System.Windows.Forms

Namespace HarrisAndSonsLTD
    Partial Public Class LoginForm
        Inherits Form

        Private mysqlConn As LoginDbConn

        Public Sub New()
            InitializeComponent()
            mysqlConn = New LoginDbConn()
            mysqlConn.connect()
        End Sub

        Private Sub Signinbtn_Click(ByVal sender As Object, ByVal e As EventArgs)
            If Usernametxb.Text = "" Then
                MessageBox.Show("Please enter a valid username")
                Usernametxb.Focus()
            ElseIf Passwordtxb.Text = "" Then
                MessageBox.Show("Password Incorrect")
                Passwordtxb.Focus()
            End If

            If Usernametxb.Text <> "" And Passwordtxb.Text <> "" Then

                If True Then
                    MessageBox.Show("Login Successful")
                    Close()
                    Dim ContactsForm As New ContactsForm
                    ContactsForm.Show()
                End If

                If True Then
                    MessageBox.Show("Incorrect Username or Password")
                End If
            End If
        End Sub

        Private Sub Usernametxb_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        End Sub

        Private Sub InitializeComponent()
            Me.logintitle = New System.Windows.Forms.Label()
            Me.Label1 = New System.Windows.Forms.Label()
            Me.Label2 = New System.Windows.Forms.Label()
            Me.Usernametxb = New System.Windows.Forms.TextBox()
            Me.Passwordtxb = New System.Windows.Forms.TextBox()
            Me.Signinbtn = New System.Windows.Forms.Button()
            Me.SuspendLayout()
            '
            'logintitle
            '
            Me.logintitle.AutoSize = True
            Me.logintitle.Font = New System.Drawing.Font("Comic Sans MS", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
            Me.logintitle.ForeColor = System.Drawing.Color.Blue
            Me.logintitle.Location = New System.Drawing.Point(75, 9)
            Me.logintitle.Name = "logintitle"
            Me.logintitle.Size = New System.Drawing.Size(247, 23)
            Me.logintitle.TabIndex = 0
            Me.logintitle.Text = "Harris and Sons Consulting LTD."
            '
            'Label1
            '
            Me.Label1.AutoSize = True
            Me.Label1.Location = New System.Drawing.Point(48, 84)
            Me.Label1.Name = "Label1"
            Me.Label1.Size = New System.Drawing.Size(63, 15)
            Me.Label1.TabIndex = 1
            Me.Label1.Text = "Username:"
            '
            'Label2
            '
            Me.Label2.AutoSize = True
            Me.Label2.Location = New System.Drawing.Point(51, 128)
            Me.Label2.Name = "Label2"
            Me.Label2.Size = New System.Drawing.Size(60, 15)
            Me.Label2.TabIndex = 2
            Me.Label2.Text = "Password:"
            '
            'Usernametxb
            '
            Me.Usernametxb.Location = New System.Drawing.Point(117, 84)
            Me.Usernametxb.Name = "Usernametxb"
            Me.Usernametxb.Size = New System.Drawing.Size(204, 23)
            Me.Usernametxb.TabIndex = 3
            Me.Usernametxb.Text = """Testuser"""
            '
            'Passwordtxb
            '
            Me.Passwordtxb.Location = New System.Drawing.Point(117, 128)
            Me.Passwordtxb.Name = "Passwordtxb"
            Me.Passwordtxb.Size = New System.Drawing.Size(204, 23)
            Me.Passwordtxb.TabIndex = 4
            Me.Passwordtxb.Text = "password"
            '
            'Signinbtn
            '
            Me.Signinbtn.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
            Me.Signinbtn.Location = New System.Drawing.Point(117, 192)
            Me.Signinbtn.Name = "Signinbtn"
            Me.Signinbtn.Size = New System.Drawing.Size(153, 73)
            Me.Signinbtn.TabIndex = 5
            Me.Signinbtn.Text = "Log In"
            Me.Signinbtn.UseVisualStyleBackColor = False
            '
            'LoginForm
            '
            Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
            Me.ClientSize = New System.Drawing.Size(355, 298)
            Me.Controls.Add(Me.Signinbtn)
            Me.Controls.Add(Me.Passwordtxb)
            Me.Controls.Add(Me.Usernametxb)
            Me.Controls.Add(Me.Label2)
            Me.Controls.Add(Me.Label1)
            Me.Controls.Add(Me.logintitle)
            Me.Name = "LoginForm"
            Me.Text = "Login"
            Me.ResumeLayout(False)
            Me.PerformLayout()

        End Sub

        Friend WithEvents logintitle As Label
        Friend WithEvents Label1 As Label
        Friend WithEvents Label2 As Label
        Friend WithEvents Usernametxb As TextBox
        Friend WithEvents Passwordtxb As TextBox
        Friend WithEvents Signinbtn As Button
    End Class
End Namespace

